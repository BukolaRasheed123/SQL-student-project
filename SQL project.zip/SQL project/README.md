# SQL Student Project for AltSchool of Data Engineering Karatu 2024 Second Semester Project Exam

## Submitted by: Bukola Rasheed

